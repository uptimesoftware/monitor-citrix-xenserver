#!/bin/sh
python ../../plugins/scripts/monitor-citrix-xenserver/monitor-citrix-xenserver.py -p $UPTIME_PASSWORD -h $UPTIME_HOSTNAME -u $UPTIME_USERNAME
