#!/bin/sh
python monitor-citrix-xenserver.py -p $UPTIME_PASSWORD -h $UPTIME_HOSTNAME -u $UPTIME_USERNAME
